# MERN Task Manager
A simple MERN stack task manager app with CRUD operations.